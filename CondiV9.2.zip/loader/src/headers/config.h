#pragma once

#define HTTP_SERVER "3.104.38.137"
#define HTTP_PORT 80

#define TFTP_SERVER "3.104.38.137"
